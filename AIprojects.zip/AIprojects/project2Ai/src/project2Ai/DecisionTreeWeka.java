package project2Ai;

import weka.core.converters.ConverterUtils.DataSource;
import weka.core.Instances;
import weka.gui.treevisualizer.PlaceNode1;
import weka.classifiers.trees.J48;
import weka.classifiers.Evaluation;
import weka.gui.treevisualizer.TreeVisualizer;

import javax.swing.*;
import java.awt.*;
import java.io.File;
import java.awt.image.BufferedImage;
import javax.imageio.ImageIO;

public class DecisionTreeWeka {

	public static void main(String[] args) {
		try {
			Instances data =  getDataset("C:\\Users\\BisanCo\\Downloads\\car.arff");
			System.out.println("*** Model 1 {70% Train | 30% Test} ***");

			Instances[] split1 = splitDataset(data, 0.7);
			J48 tree1 = modelTrain(split1[0]);
			Evaluation evaluation1 = evaluateModel(tree1, split1[0], split1[1]);

			System.out.println(evaluation1.toSummaryString());
			System.out.printf("Accuracy: %.4f%%\n", evaluation1.pctCorrect());
			evaluateF1(evaluation1, split1[1]);
			
			System.out.println("*** Model 2 {50% Train | 50% Test} ***");
			Instances[] split2 = splitDataset(data, 0.5);
			J48 tree2 = modelTrain(split2[0]);
			Evaluation evaluation2 = evaluateModel(tree2, split2[0], split2[1]);

			System.out.println(evaluation2.toSummaryString());
			System.out.printf("Accuracy: %.4f%%\n", evaluation2.pctCorrect());
			evaluateF1(evaluation2, split2[1]);

			displayTree(tree1, "Model 1 DecisionTree (70% T/ 30% Tst)");
			displayTree(tree2, "Model 2 DecisionTree (50% T / 50% Tst)");

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	private static Instances getDataset(String path) throws Exception {
		DataSource source = new DataSource(path);
		Instances data = source.getDataSet();
		if (data.classIndex() == -1) {
			data.setClassIndex(data.numAttributes() - 1);
		}
		return data;
	}

	private static void evaluateF1(Evaluation evaluation, Instances data) throws Exception {
		for (int i = 0; i < data.numClasses(); i++) {
			System.out.printf("Class %s:\n", data.classAttribute().value(i));
			double f1Score = evaluation.fMeasure(i);
			System.out.printf("  F1 Score: %.5f\n", f1Score);
		}
		System.out.printf("\nWeighted F1 Score: %.5f\n", evaluation.weightedFMeasure());
		System.out.println();
	}

	private static J48 modelTrain(Instances trainData) throws Exception {
		J48 tree = new J48();
		tree.setOptions(new String[] { "-C", "0.25", "-M", "5" });
		tree.buildClassifier(trainData);
		return tree;
	}

	private static Instances[] splitDataset(Instances data, double trainPercent) {
		data.randomize(new java.util.Random(System.currentTimeMillis()));

		int trainSize = (int) Math.round(data.numInstances() * trainPercent);
		int testSize = data.numInstances() - trainSize;

		Instances trainData = new Instances(data, 0, trainSize);
		Instances testData = new Instances(data, trainSize, testSize);

		System.out.println("Training data size(Number of instances): " + trainData.numInstances());
		System.out.println("Testing data size(Number of instances): " + testData.numInstances());

		return new Instances[] { trainData, testData };
	}

	private static Evaluation evaluateModel(J48 tree, Instances trainData, Instances testData) throws Exception {
		Evaluation eval = new Evaluation(trainData);
		eval.evaluateModel(tree, testData);
		return eval;
	}

	private static void displayTree(J48 tree, String title) throws Exception {
		JFrame frame = new JFrame(title);
		frame.setSize(2200,2000);
		frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

		TreeVisualizer treeVisual = new TreeVisualizer(null, tree.graph(), new PlaceNode1());
		frame.getContentPane().add(treeVisual, BorderLayout.CENTER);
		frame.setVisible(true);
		treeVisual.fitToScreen();

		BufferedImage image = new BufferedImage(frame.getWidth(), frame.getHeight(), BufferedImage.TYPE_INT_ARGB);
		Graphics2D graph = image.createGraphics();
		frame.paint(graph);
		graph.dispose();
		ImageIO.write(image, "png", new File("decisionTree.png"));
	}
}