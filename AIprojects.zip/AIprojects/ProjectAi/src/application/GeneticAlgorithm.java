package application;

import java.util.ArrayList;
import java.util.Random;

public class GeneticAlgorithm {
	private static ArrayList<Integer> convergenceRates = new ArrayList<>();

	private int populationSize;
	private int maxGenerations;
	private double mutationRate;
	private double crossoverRate;

	public void GeneticAlgoritm() {
	}

	public int getPopulationSize() {
		return populationSize;
	}

	public void setPopulationSize(int populationSize) {
		this.populationSize = populationSize;
	}

	public int getMaxGenerations() {
		return maxGenerations;
	}

	public void setMaxGenerations(int maxGenerations) {
		this.maxGenerations = maxGenerations;
	}

	public double getMutationRate() {
		return mutationRate;
	}

	public void setMutationRate(double mutationRate) {
		this.mutationRate = mutationRate;
	}

	public double getCrossoverRate() {
		return crossoverRate;
	}

	public void setCrossoverRate(double crossoverRate) {
		this.crossoverRate = crossoverRate;
	}

	public ArrayList<Integer> getConvergenceRates() {
		return convergenceRates;
	}

	public void setConvergenceRates(ArrayList<Integer> convergenceRates) {
		this.convergenceRates= convergenceRates;
	}

	public String generateRandomBinaryPassword(int length) {
		StringBuilder binary = new StringBuilder();
		Random random = new Random();

		for (int i = 0; i < length; i++) {
			if (random.nextBoolean()) {
				binary.append('0');
			} else {
				binary.append('1');
			}
		}
		return binary.toString();
	}

	public String generateRandomSolution(int length) {
		return generateRandomBinaryPassword(length);
	}

	public ArrayList<String> generatePopulation(int populationSize, int solutionLength) {
		ArrayList<String> population = new ArrayList<>();
		for (int i = 0; i < populationSize; i++) {
			population.add(generateRandomSolution(solutionLength));
		}
		return population;
	}

	public int calculateFitness(String currentString, String target) {
		int fitness = 0;
		for (int i = 0; i < target.length(); i++) {
			if (currentString.charAt(i) == target.charAt(i)) {
				fitness++;

			}
		}
		return fitness;
	}

	public String selectParent(ArrayList<String> population, ArrayList<Integer> fitnessScores) {
		int totalFitness = 0;
		for (int fitness : fitnessScores) {
			totalFitness += fitness;
		}
		int randomNum = new Random().nextInt(totalFitness);

		int sumFitness = 0;
		for (int i = 0; i < population.size(); i++) {
			sumFitness += fitnessScores.get(i);
			if (sumFitness >= randomNum) {
				return population.get(i);
			}
		}

		return population.get(0);

	}

	public String crossover(String parent1, String parent2, double crossoverRate) {
		Random random = new Random();
		if (random.nextDouble() < crossoverRate) {
			int crossoverPoint = random.nextInt(parent1.length());
			return parent1.substring(0, crossoverPoint) + parent2.substring(crossoverPoint);
		}
		return parent1;
	}

	public String mutate(String solution, double mutationRate) {
		StringBuilder mutated = new StringBuilder();
		Random random = new Random();
		for (int i = 0; i < solution.length(); i++) {
			if (random.nextDouble() < mutationRate) {
				if (solution.charAt(i) == '0') {
					mutated.append('1');
				} else if (solution.charAt(i) == '1') {
					mutated.append('0');
				}
			} else {
				mutated.append(solution.charAt(i));
			}
		}
		return mutated.toString();
	}

	public void runGeneticAlgorithm(String target, int populationSize, int maxGenerations, double mutationRate,
			double crossoverRate) {
		ArrayList<String> population = generatePopulation(populationSize, target.length());

		for (int generation = 0; generation < maxGenerations; generation++) {

			ArrayList<Integer> fitnessScores = new ArrayList<>();
			for (String solution : population) {
				fitnessScores.add(calculateFitness(solution, target));
			}

			int maxFitness = 0;
			String bestSolution = "";
			for (int i = 0; i < fitnessScores.size(); i++) {
				if (fitnessScores.get(i) > maxFitness) {
					maxFitness = fitnessScores.get(i);
					bestSolution = population.get(i);
				}
			}

			System.out.println("Generation: " + generation + " | Best Fitness: " + maxFitness);
			System.out.println("Best Solution So Far: " + bestSolution);

			getConvergenceRates().add(maxFitness);

			if (maxFitness == target.length()) {
				System.out.println("Password found in generation " + generation);
				System.out.println("Password: " + bestSolution);
				return;
			}

			ArrayList<String> nextPopulation = new ArrayList<>();
			while (nextPopulation.size() < populationSize) {
				String parent1 = selectParent(population, fitnessScores);
				String parent2 = selectParent(population, fitnessScores);

				String offspring = crossover(parent1, parent2, crossoverRate);
				offspring = mutate(offspring, mutationRate);

				nextPopulation.add(offspring);
			}

			population = nextPopulation;
		}

		System.out.println("Password not found within the maximum number of generations.");
	}

}
