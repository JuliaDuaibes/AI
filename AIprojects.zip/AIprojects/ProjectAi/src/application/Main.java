package application;

import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.chart.LineChart;
import javafx.scene.chart.NumberAxis;
import javafx.scene.chart.XYChart;
import javafx.stage.Stage;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;

public class Main extends Application {
	private static GeneticAlgorithm GA = new GeneticAlgorithm();

	@Override
	public void start(Stage primaryStage) {

		Scene scene = new Scene(createChart(), 800, 600);
		scene.getRoot().setStyle(
				"-fx-background-color: linear-gradient(to bottom, #eaf7ff, #b3e0ff); " + "-fx-padding: 10px;");
		primaryStage.setScene(scene);
		primaryStage.setTitle("Convergence Rate Chart");
		primaryStage.show();
	}

	public LineChart<Number, Number> createChart() {
		NumberAxis xAxis = new NumberAxis();
		NumberAxis yAxis = new NumberAxis();
		xAxis.setLabel("Generation");
		yAxis.setLabel("Fitness");

		xAxis.setStyle("-fx-tick-label-fill: blue; -fx-font-size: 14;");
		yAxis.setStyle("-fx-tick-label-fill: blue; -fx-font-size: 14;");

		LineChart<Number, Number> lineChart = new LineChart<>(xAxis, yAxis);
		lineChart.setTitle("Convergence Rate");

		lineChart.setStyle("-fx-background-color: linear-gradient(to bottom, #ffffff, #d1e7f5); "
				+ "-fx-border-color: darkblue; " + "-fx-border-width: 2px; " + "-fx-border-radius: 5px;");

		lineChart.lookup(".chart-title")
				.setStyle("-fx-font-size: 16px; " + "-fx-font-weight: bold; " + "-fx-text-fill: darkblue;");

		XYChart.Series<Number, Number> series = new XYChart.Series<>();
		series.setName("Fitness Over Generations");

		for (int i = 0; i < GA.getConvergenceRates().size(); i++) {
			series.getData().add(new XYChart.Data<>(i, GA.getConvergenceRates().get(i)));
		}

		lineChart.getData().add(series);

		for (XYChart.Series<Number, Number> s : lineChart.getData()) {
			for (XYChart.Data<Number, Number> data : s.getData()) {

				data.getNode().setStyle(
						"-fx-background-color: radial-gradient(center 50% 50%, radius 60%, #ff0000, #ffffff); "
								+ "-fx-background-radius: 5px;");
			}
		}
		lineChart.lookupAll(".chart-series-line")
				.forEach(node -> node.setStyle("-fx-stroke-width: 3px; " + "-fx-stroke: #E49CB4;"));
		return lineChart;
	}

	public static void saveConvergenceRatesToFile(String filename) {
		try (BufferedWriter writer = new BufferedWriter(new FileWriter(filename))) {
			writer.write("Generation,Fitness\n");
			for (int i = 0; i < GA.getConvergenceRates().size(); i++) {
				writer.write(i + "," + GA.getConvergenceRates().get(i) + "\n");
			}
			System.out.println("Convergence rates successfully saved to " + filename);
		} catch (IOException e) {
			System.err.println("Error while saving convergence rates to file: " + e.getMessage());
		}
	}

	public static void main(String[] args) {
		int passwordLength = 32;
		String target = GA.generateRandomBinaryPassword(passwordLength);
		System.out.println("Generated Target Password: " + target);

		int populationSize = 300;
		int maxGenerations = 200;
		double mutationRate = 0.01;
		double crossoverRate = 0.9;

		GA.runGeneticAlgorithm(target, populationSize, maxGenerations, mutationRate, crossoverRate);

		saveConvergenceRatesToFile("convergence_rates.csv");
		launch(args);
	}

}
